#include <iostream>

#include "TestScurt.h"
#include "TestExtins.h"

int main(){
    testAll();
    std::cout<<"Finished LI Tests!"<<std::endl;
    testAllExtins();
    std::cout<<"Finished LI Tests EXT!"<<std::endl;
}