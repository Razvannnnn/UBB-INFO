#ifndef TESTE_H
#define TESTE_H

#include "produse.h"
#include "repo.h"
#include <QString>
#include <vector>
#include <string>

using namespace std;

class Teste
{
public:
    Teste(){}
    void testAll();
};

#endif // TESTE_H
